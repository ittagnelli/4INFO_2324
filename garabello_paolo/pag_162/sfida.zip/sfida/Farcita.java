public class Farcita {
    @Override
    public String toString(){
        return "farcita";
    }    
}
