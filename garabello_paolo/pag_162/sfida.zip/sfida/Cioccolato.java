public class Cioccolato {
    @Override
    public String toString(){
        return "al cioccolato";
    }
}
