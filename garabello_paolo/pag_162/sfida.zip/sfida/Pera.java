public class Pera {
    @Override
    public String toString(){
        return "alla pera";
    }       
}
