public class Prosciutto {
    @Override
    public String toString(){
        return "al prosciutto";
    }
    
}