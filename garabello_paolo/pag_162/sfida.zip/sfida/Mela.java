public class Mela {
    @Override
    public String toString(){
        return "alla mela";
    }   
}
