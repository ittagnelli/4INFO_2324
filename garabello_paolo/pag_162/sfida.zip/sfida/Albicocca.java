public class Albicocca {
    @Override
    public String toString(){
        return "alla albicocca";
    }      
}
