public class Frizzante {
    @Override
    public String toString(){
        return "Frizzante";
    }
}
